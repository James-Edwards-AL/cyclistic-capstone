# Cyclistic Bike-Share Case Study

## 📊 Project Overview
This project was completed as the capstone for the Google Data Analytics Certificate. I analyzed 12 months of bike-share data from a fictional company, Cyclistic, to uncover user behavior patterns and develop strategies to increase annual memberships.

## 🎯 Business Task
Determine how casual riders and annual members use bikes differently and recommend strategies to convert casual riders into annual members.

## 🧠 Key Insights
- Casual riders take significantly longer rides (avg 23:49) than members (avg 12:47)
- Casual riders mostly ride on weekends; members are more consistent during weekdays
- Classic bikes are the most preferred, followed by electric bikes. Docked bikes are rarely used

## 📈 Tools Used
- Excel (Power Query, Pivot Tables, Custom Formulas)
- PowerPoint (Data Presentation and Visualization)

## 📎 Files Included
- `Cyclistic_Capstone_Presentation.pptx`: Final presentation with speaker notes
- `Cyclistic_Capstone_Presentation.pdf`: PDF version for easy viewing

## 🔗 Data Source
Divvy Bikes Trip Data (used for Cyclistic scenario)  
[https://divvy-tripdata.s3.amazonaws.com/index.html](https://divvy-tripdata.s3.amazonaws.com/index.html)

## 💬 Contact
Tori Edwards  
Google Certified Data Analyst | WGU B.S. Business - Supply Chain Management  
Open to analyst roles in logistics, supply chain, and operations
